import React from 'react'
import Product from '../components/product'

const Home = () => {
  return (
    <Product/>
  )
}

export default Home
