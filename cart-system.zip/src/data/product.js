export const productItem = [
    {
        title: "CAMBRIC PRINTED 2PC STITCHED",
        price: 45,
        img: "1.webp",
        id: "001",
    },
    {
        title: "CAMBRIC PRINTED 2PC STITCHED",
        price: 45,
        img: "2.webp",
        id: "002",
    },
    {
        title: "CAMBRIC PRINTED 2PC STITCHED",
        price: 45,
        img: "3.webp",
        id: "003",
    },
    {
        title: "CAMBRIC PRINTED 2PC STITCHED",
        price: 45,
        img: "4.webp",
        id: "004",
    },
    {
        title: "CAMBRIC PRINTED 2PC STITCHED",
        price: 45,
        img: "5.webp",
        id: "005",
    },
    {
        title: "CAMBRIC PRINTED 2PC STITCHED",
        price: 45,
        img: "6.webp",
        id: "006",
    },
    {
        title: "CAMBRIC PRINTED 2PC STITCHED",
        price: 45,
        img: "7.webp",
        id: "007",
    },
    {
        title: "CAMBRIC PRINTED 2PC STITCHED",
        price: 45,
        img: "8.webp",
        id: "008",
    },
]